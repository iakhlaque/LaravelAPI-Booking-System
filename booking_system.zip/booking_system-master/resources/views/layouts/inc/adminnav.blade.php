 <!-- Navbar -->
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top " id="navigation-example">
     <div class="container-fluid">
         <div class="navbar-wrapper">
             <a class="navbar-brand">Admin Dashboard</a>
         </div>
         <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index"
             aria-expanded="false" aria-label="Toggle navigation" data-target="#navigation-example">
             <span class="sr-only">Toggle navigation</span>
             <span class="navbar-toggler-icon icon-bar"></span>
             <span class="navbar-toggler-icon icon-bar"></span>
             <span class="navbar-toggler-icon icon-bar"></span>
         </button>
         <div class="dropdown" style="margin-right: 20px;">
             <ul class="navbar-nav">
                 <li class="nav-item dropdown">
                     <a class="nav-link" href="javscript:void(0)" id="navbarDropdownMenuLink" data-toggle="dropdown"
                         aria-haspopup="true" aria-expanded="false">
                     </a>
                 </li>
             </ul>
         </div>
     </div>
 </nav>
 <!-- End Navbar -->